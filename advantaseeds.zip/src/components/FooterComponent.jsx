import React from 'react';

const FooterComponent = () => {
  return (
    <section className="row bg-dark">
      <div className="col-md-4 text-warning p-5">
        <h1>Company</h1>
         <img src="static/imagess/bee4.jpeg" alt="About Us" width="300" height="200" />
      </div>

      <div className="col-md-4 text-warning">
        <h3>Contact us</h3>
        <br />
        <br />
           <p>Advanta Africa Ltd Western Height
6th Floor Karuna Rd in Westlands
near Sarit centre Nairobi Kenya -00100
            </p>    
               

       
          <br />
          <img src="static/imagess/my logo.jpeg" alt="Download" width="250" height="100" />
        
        
      </div>

      <div className="col-md-4">
        <h6 className="text-warning">Be in touch with us anytime, anywhere</h6>
        <br />
        <img src="static/imagess/Imagesss/fb.png" alt="Facebook" width="100" height="100" />
        <br />
        <img src="static/imagess/Imagesss/in.png" alt="Instagram" width="100" height="100" />
        
        <img src="static/imagess/Imagesss/x.png" alt="Twitter" width="100" height="100" />
        
        <img src="static/imagess/warrup.jpeg" alt="whatsapp" width="100" height="100" />

        <p className="text-dark">
        
        </p>
      </div>

      <div className="col-md-12 text-white text-center bg-dark p-8">
        <h3>
          <marquee behavior="" direction="left">
            Produced by Benahashim. © 2025. All rights reserved
          </marquee>
        </h3>
      </div>
    </section>
  );
};

export default FooterComponent;
