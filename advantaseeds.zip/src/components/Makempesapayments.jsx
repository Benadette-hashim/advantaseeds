import React from 'react'
import axios from 'axios'
import { useState } from 'react'
import { useLocation } from 'react-router-dom'

const MpesaPayment = () => {
    const[loading,setLoading]=useState("")
    const[message,setMessage]=useState("")
    const[phone,setPhone]=useState("")
    const[error,setError]=useState("")
    const {product}=useLocation().state || {}

    const submit= async(e)=>{
      e.preventDefault();
      setLoading('')
    
    try {
      // we use form data 
      const data=new FormData()
 
      data.append("phone",phone)
      data.append("amount",product.cost)
      
    const response=await axios.post("https://benadetteqwamboka.pythonanywhere.com/api/mpesa_payment",data)
      
      setLoading("")
     
      setMessage(response.data.message)
  
    } catch (error) {
      setLoading("")
  
      setError(error.message) 
    }
  
  }
    
  return (
    <div className='row justify-content-center'>
        <h2 className='mt-4'>MakePayments-Lipa na Mpesa</h2>

        <div className='col-md-6 p-4 card shadow'>

           <p className='text-info'>Product name;{product.product_name}</p> 
           <p className='text-warning'>Product cost{product.product_cost}</p>  


         <form action="" onSubmit={submit}> 

        <p className='text-warning'>{loading}</p>
        <p className='text-success'>{message}</p>
        <p className='text-error'>{error}</p>

            <input type="tel" placeholder='254xxxxxxxx'className='form-control' value={phone} onChange={(e)=>setPhone(e.target.value)}/>
            <br />
            <br />
            <button className='btn btn-dark' type='submit'>Make payments</button>
        </form>
        </div>
        </div>
  )
}

export default MpesaPayment