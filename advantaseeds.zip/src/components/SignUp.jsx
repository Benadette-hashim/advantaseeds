import React from 'react'
import {Link} from 'react-router-dom'

import { useState } from "react"; // for state management 
import axios from "axios"; //For backend API access
const  SignUp=() =>  {

  const[username,setUsername]=useState("")
  const[email,setEmail]=useState("")
  const[phone,setPhone]=useState("")
  const[password,setPassword]=useState("")
  const[success,setSuccess]=useState("")
  const[loading,setLoading]=useState("")
  const[error,setError]=useState("")

  

  // function to handle form submit 
  const submit= async(e)=>{
    e.preventDefault();
    setLoading("Please wait as we upload  your data")
   

  try {
    // we use form data 
    const data=new FormData()

    data.append("username",username)
    data.append("email",email)
    data.append("phone",phone)
    data.append("password",password)
    // console.log(response) 

    const response=await axios.post("https://modcom2.pythonanywhere.com/api/signup",data)

    setLoading("")
     // console.log(response) 
    setSuccess (response.data.message)

  } catch (error) {
    setLoading("")

    setError(error.message) 
  }

  }
  

  return (
    <div className='row justify-content-center mt-4'>

       <div className='col-md-6 p-4 card shadow'>
        {/* <h1>Welcome to SignUp page</h1> */}
        <h2 className='bg-info'>Sign up</h2>

       

        <form action="" onSubmit={submit}> 
          {/* called from up there as an event listener  */}

          <p className='text-warning'>{loading}</p>
        <p className='text-success'>{success}</p>
        <p className='text-error'>{error}</p>

          <input  type="text"placeholder='Enter your Username' className='form-control' required onChange={(e) =>setUsername(e.target.value)} value={username}/>
          {username}
          <br />
          <br />
          <input type="email"placeholder='Enter your Email' className='form-control' required onChange={(e) =>setEmail(e.target.value)} value={email} />
          <br />
          <br />
          <input type="number"placeholder='Enter your Phone' className='form-control' required onChange={(e) =>setPhone(e.target.value)} value={phone}/>
          <br />
          <br />
          <input type="password"placeholder='Enter your Password'className='form-control'required onChange={(e) =>setPassword(e.target.value)} value={password}/>
          <br />
          <br />
           
           <button className='btn btn-primary'>sign up</button>
            

        </form>
        Already have an account?<Link to="/signin">Signin</Link>
        
      </div>
      </div>
  )             
}

export default SignUp