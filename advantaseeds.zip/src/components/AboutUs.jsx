import React from "react";

const AboutUs = () => {
return (
<section className="container mt-5  mb-5 rounded" >
<div className="row " >
<div className="col-md-12 text-center">
<h1 className="fw-bold">About Advanta Seeds</h1>
<p className="lead">
At Advanta, we are passionate about helping gardeners of all levels grow with confidence. We specialize in providing high-quality and carefully curated seeds for a variety of plants. Our mission is to bring nature closer to you by offering sustainable, non-GMO seeds that ensure the best results for your garden.

Thank you for choosing us to be part of your growing experience!
</p>
</div>
</div>

<section className="our-story py-5">
  <div className="container">
    <div className="row">
      {/* Our Story Section */}
      <div className="col-md-6">
        <h2 className="fw-bold">Our Story</h2>
        <p>
          Advanta Seeds was founded in 1994 as a joint venture between ITC Limited and Zeneca Limited, initially named ITC Zeneca Limited, and later changed to Advanta India Limited in 1998, with the objective of researching, developing, producing, marketing, and selling hybrid seeds.
        </p>
      </div>

      {/* Why Choose Us Section */}
      <div className="col-md-6">
        <h2 className="fw-bold text-right">Why Choose Us?</h2>
        <div className="d-flex align-items-center mb-3">
          <span>High-Quality Products</span>
        </div>
        <div className="d-flex align-items-center mb-3">
          <span>Affordable Prices</span>
        </div>
        <div className="d-flex align-items-center mb-3">
          <span>Fast & Reliable Delivery</span>
        </div>
        <div className="d-flex align-items-center mb-3">
          <span>Excellent Customer Service</span>
        </div>
      </div>
    </div>
  </div>
</section>


  </section>






);
};

export default AboutUs;