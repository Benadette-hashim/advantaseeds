import React from 'react';

const CarouselComponent = () => {
  return (
    <section className="row">
      <div className="col-md-12">
        {/* carousel starts here */}
        <div className="carousel slide" data-bs-ride="carousel" id="mycarousel">
          {/* wrapping images or item */}
          <div className="carousel-inner">
            <div className="carousel-item active ">
              <img 
                src="static/imagess/bee1.jpg" 
                alt="" 
                className="" 
                width="1000" 
                height="600" 
              />
              <h4 className="bg-dark display text-center"></h4>
            </div>

          
            <div className="carousel-item">
              <img 
                src="static/imagess/bee13.jpeg" 
                alt="Epoxy Image" 
                className="" 
                width="1000" 
                height="700" 
              />
            </div>

            <div className="carousel-item">
              <img 
                src="static/imagess/bee16.jpeg" 
                alt="Epoxy Image" 
                className="" 
                width="1000" 
                height="700" 
              />
            </div>

            <div className="carousel-item">
              <img 
                src="static/imagess/bee15.jpeg" 
                alt="" 
                className="" 
                width="1000" 
                height="700" 
              />
            </div>
          </div>

          {/* controllers */}
          <a 
            href="#mycarousel" 
            className="carousel-control-prev" 
            data-bs-slide="prev"
          >
            <span className="carousel-control-prev-icon bg-danger" />
          </a>

          <a 
            href="#mycarousel" 
            className="carousel-control-next" 
            data-bs-slide="next"
          >
            <span className="carousel-control-next-icon bg-danger" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default CarouselComponent;
