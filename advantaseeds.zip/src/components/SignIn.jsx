import React from 'react'
import {Link, useNavigate} from 'react-router-dom'
import { useState } from "react"; // for state management 
import axios from "axios"; //For backend API access
const  SignIn=() =>{

      const[email,setEmail]=useState("");
      const[password,setPassword]=useState("");
      const[success,setSuccess]=useState("");
      const[loading,setLoading]=useState("");
      const[error,setError]=useState("")
      const navigate=useNavigate()


      const submit= async(e)=>{
        e.preventDefault();
        setLoading("Please wait as we log you in data")

        try {
          // we use form data (js object used to send data in form of key and value)
          const data=new FormData()
          
          data.append("email",email)
          data.append("password",password)
           
      
          const response=await axios.post("https://Benadetteqwamboka.pythonanywhere.com/api/signin",data)
          console.log(response)

          setLoading("")
           // console.log(response) 
          setSuccess (response.data.message)

          if(response.data.user){
            navigate("/")
          }
      
        } catch (error) {
          setLoading("")
      
          setError(error.message) 
        }
      
        }

  return (
    <div className='row justify-content-center mt-4>'>

    <div className='col-md-6 p-4 card shadow'>
      {/* <h1>>Welcome to SignIn Page</h1*/}

      <br />
      <br />
      <h2 className='bg-info '>Sign In</h2>
    <br />
    <br />
    <form action="" onSubmit={submit}>

        <p className='text-warning'>{loading}</p>
        <p className='text-success'>{success}</p>
        <p className='text-error'>{error}</p>

      <input type="email" placeholder='Enter email' className='form-control ' required onChange={(e) =>setEmail(e.target.value)} value={email}/>
      <br />
      <br />
      <input type="password" placeholder='Enter password' className='form-control' required onChange={(e) =>setPassword(e.target.value)} value={password}/>
      <br />
      <br />
      <button className='btn btn-primary'>sign In</button>

            
      
    </form>
      Don't have an account? Please
      <br />
      <br />
      <Link to="/SignUp">signUp</Link>

     </div>



      </div>

 




  )
}

export default SignIn