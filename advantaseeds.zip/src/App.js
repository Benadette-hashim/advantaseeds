import React from "react";
import CarouselComponent from "./components/CarouselComponent";
import FooterComponent from "./components/FooterComponent";
import './App.css';
import SignUp from './components/SignUp';
import SignIn from './components/SignIn';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.js'
import { BrowserRouter as Router, Route, Routes} from "react-router-dom";
import AddProducts from './components/Addproducts';
import GetProducts from './components/Getproducts';
import Makempesapayments from './components/Makempesapayments';
import Navbar from "./components/Navbar";
import AboutUs from "./components/AboutUs";
import "./Benah.css"
function App() {
  return (
    <Router>
    <div className="App">
      <header className="App-header">
        <h1>Advantaseeds E-commerce online</h1>
        <br />
        <br />
       
      </header>
       
      <Navbar/>
      <Routes>
        <Route path='/signup' element={<SignUp/>}/>;
        <Route path='/signin' element={<SignIn/>}/>;
        <Route path='/addproducts' element={<AddProducts/>}/>;
        <Route path='/getproducts' element={<GetProducts/>}/>;
        <Route path='/makepayments' element={<Makempesapayments/>}/>;
        <Route path='/aboutus' element={<AboutUs/>}/>;
       
       
      
       
      </Routes>
    
     
    </div>
  
    </Router>
  );
}

export default App;

